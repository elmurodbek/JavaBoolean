import java.util.Scanner;

public class boolean1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;
        boolean m;

        a = in.nextInt();
        m = a>0;

        System.out.println("a soni musbat: " + m);
    }
}
