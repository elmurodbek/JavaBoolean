import java.util.Scanner;

public class boolean2 {
    public static void main(String[] args) {
        int a,b;
        boolean m;
        Scanner in = new Scanner(System.in);
        a = in.nextInt();

        b = a%2;

        m = (b!=0);
        System.out.println("son toq: " + m);
    }
}
