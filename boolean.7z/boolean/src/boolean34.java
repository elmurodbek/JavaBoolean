import java.util.Scanner;

public class boolean34 {
    public static void main(String[] args) {
        int x,y,c;
        boolean m;
        Scanner in = new Scanner(System.in);

        System.out.print("x = ");
        x = in.nextInt();
        System.out.print("y = ");
        y = in.nextInt();

        c = x+y;
        m = (c%2 != 0);
        System.out.println("maydon oq: " + m);
    }
}
