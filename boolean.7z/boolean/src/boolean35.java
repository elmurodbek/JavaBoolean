import java.util.Scanner;

public class boolean35 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x1,x2,y1,y2,m1,m2;
        boolean n2, n1;

        System.out.print("x1: ");
        x1 = in.nextInt();
        System.out.print("y1: ");
        y1 = in.nextInt();
        System.out.print("x2: ");
        x2 = in.nextInt();
        System.out.print("y2: ");
        y2 = in.nextInt();

        m1 = x1+x2;
        m2 = y1+y2;
        n1 = (( m1 % 2 == 0) && ( m2 % 2 == 0 )) || (( m1 % 2 != 0 ) && ( m2 % 2 != 0 ));

        System.out.println("bir xil: " + n1);
    }
}
