public class boolean39 {
    public static void main(String[] args) {

    }
}
