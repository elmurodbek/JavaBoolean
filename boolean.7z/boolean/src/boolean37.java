import java.util.Scanner;

public class boolean37 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x1,x2,y1,y2;
        boolean m,m1,m2;

        System.out.print("x1: ");
        x1 = in.nextInt();
        System.out.print("y1: ");
        y1 = in.nextInt();
        System.out.print("x2: ");
        x2 = in.nextInt();
        System.out.print("y2: ");
        y2 = in.nextInt();

        m = ( (x1>=1)&&(x1<=8)&&(y1>=1)&&(y1<=8)&&(x2>=1)&&(x2<=8)&&(y2>=1)&&(y2<=8) );
        m1 = (x2-x1==1 && y2-y1==1) || (x2 == x1 && y2-y1 == 1) || (y2 == y1 && x2-x1 == 1);
        m2 = m==true && m1 ==true;
        System.out.print("shoh: " + m2);
    }
}
