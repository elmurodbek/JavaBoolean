import java.util.Scanner;

public class boolean38 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int x1,x2,y1,y2;
        boolean m1,m2,m3;
        System.out.print("x1: ");
        x1 = in.nextInt();
        System.out.print("y1: ");
        y1 = in.nextInt();
        System.out.print("x2: ");
        x2 = in.nextInt();
        System.out.print("y2: ");
        y2 = in.nextInt();

        m1 = (x1>=1 && x1<=8) && (y1>=1 && y1<=8);
        m2 = (x2>=1 && x2<=8) && (y2>=1 && y2<=8);

        m3 = m1 == true && m2 == true && (x1+y1 == x2+y2 || ((x1+y1)%2==0) && x1!=x2 && y1!=y2);

        System.out.println("fil: " + m3);

    }
}
