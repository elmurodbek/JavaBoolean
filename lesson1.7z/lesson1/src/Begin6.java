import java.util.Scanner;

public class Begin6 {
    public static void main(String[] args) {
        //double x = Math.PI;
        double a,b,c,V,S;
        System.out.println("V = a*b*c  /  S = 2*(a*b + b*c + a*c");
        Scanner input = new Scanner(System.in);
        System.out.println("a = ");
        a = input.nextDouble();
        System.out.println("b = ");
        b = input.nextDouble();
        System.out.println("c = ");
        c = input.nextDouble();

        V = a*b*c;
        S = 2*(a*b + b*c + a*c);

        System.out.println("V= " + V + "\nS= " + S);

    }
}
