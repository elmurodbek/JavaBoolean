import java.util.Scanner;

public class Begin17 {
    public static void main(String[] args) {
        double a,b,c,ac,bc,ac1;
        Scanner in = new Scanner(System.in);
        System.out.println("a = ");
        a = in.nextDouble();
        System.out.println("b = ");
        b = in.nextDouble();
        System.out.println("c= ");
        c = in.nextDouble();
        ac = Math.abs(a-c);
        bc = Math.abs(b-c);
        ac1 = ac+bc;
        System.out.println("ac: " + ac + "\n bc: " + bc + "\n ac1: " + ac1);
    }
}
