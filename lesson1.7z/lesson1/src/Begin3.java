import java.util.Scanner;

public class Begin3 {
    public static void main(String[] args) {
        double a, b, P, S;
        System.out.println("S = a*b     P = 2*(a+b)");

        Scanner input = new Scanner(System.in);
        System.out.println("a = ");
        a = input.nextDouble();
        System.out.println("b = ");
        b = input.nextDouble();
        S = a*b;
        P = 2*(a+b);

        System.out.println("S = " + S + "\nP = " + P);
    }
}
