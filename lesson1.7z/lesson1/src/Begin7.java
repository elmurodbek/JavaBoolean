import java.util.Scanner;

public class Begin7 {
    public static void main(String[] args) {
        System.out.println("L = 2*pi*R  /  S = pi*R*R");
        double L, S;
        double x = Math.PI;
        int R;
        System.out.println("R= ");
        Scanner input = new Scanner(System.in);
        R = input.nextInt();

        L = 2*x*R;
        S = x*R*R;

        System.out.println("L = " + L + " S = " + S);
    }
}
