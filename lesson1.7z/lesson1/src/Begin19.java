import java.util.Scanner;

public class Begin19 {
    public static void main(String[] args) {
        System.out.println("a va b. P=? S=?");
        int a,b,P,S;
        Scanner in = new Scanner(System.in);
        a = in.nextInt();
        b = in.nextInt();
        P = 2*(a+b);
        S = a*b;
        System.out.println("P = " + P + " S = " + S);
    }
}
