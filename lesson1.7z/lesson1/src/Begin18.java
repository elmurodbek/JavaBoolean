import java.util.Scanner;

public class Begin18 {
    public static void main(String[] args) {
        int a,b,c,ac,bc;
        System.out.println("AC va BC ko`paytma");
        Scanner in = new Scanner(System.in);
        System.out.println("a = ");
        a = in.nextInt();
        System.out.println("b = ");
        b = in.nextInt();
        System.out.println("c = ");
        c = in.nextInt();
        ac = Math.abs(a-b);
        bc = Math.abs(b-c);
        System.out.println("AC = " + ac + " BC = " + bc + " Natija: " + ac*bc);
    }
}
