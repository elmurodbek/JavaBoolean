import java.util.Scanner;

public class Begin14 {
    public static void main(String[] args) {
        double L,R,S;
        System.out.println("L = 2*pi*R  /  S = pi*R*R");
        double x = Math.PI;

        Scanner in = new Scanner(System.in);
        // R = L/(2*pi)
        System.out.println("L = ");
        L = in.nextDouble();
        R = L/(2*x);
        System.out.println("R = " + R);
        S = x * R * R;
        System.out.println("S = " + S);

    }
}
