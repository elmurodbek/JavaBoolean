import java.util.Scanner;

public class Begin5 {
    public static void main(String[] args) {
        double a, V, S;
        System.out.println("V = a^3  /  S = 6*a^2");

        Scanner input = new Scanner(System.in);
        System.out.print("a= ");
        a = input.nextDouble();

        V = Math.pow(a, 3);
        S = Math.pow(a,2) * 6;

        System.out.println("V= " + V);
        System.out.println("S= " + S);
    }

}
