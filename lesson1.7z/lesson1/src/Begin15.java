import java.util.Scanner;

public class Begin15 {
    public static void main(String[] args) {
        System.out.println("L = 2*pi*R  /  S = pi*R*R  /  R=?/d=?");
        double p = 3.14;
        double S, d, R;
        // R = sqrt(S/pi)
        System.out.println("S = ");
        Scanner in = new Scanner(System.in);
        S = in.nextDouble();
        R = Math.sqrt(S/p);
        System.out.println("R = " + R + " d = " + 2*R);
        System.out.println("bonus \n L = ");
        double L;
        L = 2*p*R;
        System.out.print(L);

    }
}
