import java.util.Scanner;

public class Begin28 {
    public static void main(String[] args) {
        System.out.println("a = ");
        int a;
        double a2,a3,a5,a10,a15;

        Scanner in = new Scanner(System.in);
        a = in.nextInt();
        a2 = a*a;
        a3 = a*a*a;
        a5 = Math.pow(a,5);
        a10 = Math.pow(a,10);
        a15 = Math.pow(a,15);
        System.out.println("a^2 = " + a2 + " a^3 = " + a3 + " a^5 = " + a5 + " a^10 = " + a10 + " a^15 = " + a15);
    }
}
