public class Begin35 {
    public static void main(String[] args) {

    }
}
