import java.util.Scanner;

public class Begin20 {
    public static void main(String[] args) {
        System.out.println("tekislikdagi ikki nuqta (x1,y1), (x2,y2) \nsqrt((x2-x1)^2 + (y2-y1)^2)");
        int x1,x2,y1,y2;
        double N;
        System.out.println("x1 = ");
        Scanner in = new Scanner(System.in);
        x1 = in.nextInt();
        System.out.println("y1 = ");
        y1 = in.nextInt();
        System.out.println("x2 = ");
        x2 = in.nextInt();
        System.out.println("y2 = ");
        y2 = in.nextInt();
        N = Math.sqrt(Math.pow((x2-x1),2) + Math.pow((y2-y1),2));
        System.out.println("Natija: " + N);
    }
}
