import java.util.Scanner;

public class Begin34 {
    public static void main(String[] args) {
        System.out.println("x kg shokolad a sum. y kg konfet b sum");
        int x,a,y,b,x1,y1;
        Scanner in = new Scanner(System.in);
        System.out.println("x = ");
        x = in.nextInt();
        System.out.println("a = ");
        a = in.nextInt();
        System.out.println("y = ");
        y = in.nextInt();
        System.out.println("b = ");
        b = in.nextInt();
        x1 = a/x;
        y1 = b/y;

        System.out.println("1kg shokolad = " + x1);
        System.out.println("1kg konfet = " + y1);

    }
}
