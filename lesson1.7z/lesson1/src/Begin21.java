import java.io.PipedWriter;
import java.util.Scanner;

public class Begin21 {
    public static void main(String[] args) {
        System.out.println("(x1,y1) (x2,y2) (x3,y3)");
        int x1,x2,x3,y1,y2,y3;
        double a,b,c;
        double S,p;

        System.out.println("x1 = ");
        Scanner in = new Scanner(System.in);
        x1 = in.nextInt();
        System.out.println("y1 = ");
        y1 = in.nextInt();
        System.out.println("x2 = ");
        x2 = in.nextInt();
        System.out.println("y2 = ");
        y2 = in.nextInt();
        System.out.println("x3 = ");
        x3 = in.nextInt();
        System.out.println("y3 = ");
        y3 = in.nextInt();
        a = Math.sqrt( (Math.pow( (x2-x1),2 ) + Math.pow( (y2-y1),2 ) ) );
        b = Math.sqrt( (Math.pow( (x3-x2),2 ) + Math.pow( (y3-y2),2 ) ) );
        c = Math.sqrt( (Math.pow( (x3-x1),2 ) + Math.pow( (y3-y1),2 ) ) );

        p = (a+b+c)/2;

        S = Math.sqrt( p*(p-a)*(p-b)*(p-c) );

        System.out.println("S = " + S + " p = " + p);

    }
}
