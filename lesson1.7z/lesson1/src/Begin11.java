import java.util.Scanner;

public class Begin11 {
    public static void main(String[] args) {
        int a, b, c;
        Scanner in = new Scanner(System.in);
        System.out.println("a= ");
        a = in.nextInt();
        System.out.println("b= ");
        b = in.nextInt();

        c = a+b;
        System.out.println("Natija: " + c);
        System.out.println("Ko`paytma: " + a*b);
        System.out.println("Moduli: " + Math.abs(a) + " " + Math.abs(b));
    }
}
