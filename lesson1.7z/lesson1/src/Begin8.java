import java.util.Scanner;

public class Begin8 {
    public static void main(String[] args) {
        System.out.println("(a+b)/2");
        double a,b;
        double c;

        Scanner in = new Scanner(System.in);
        System.out.println("a= ");
        a = in.nextDouble();
        System.out.println("b= ");
        b = in.nextDouble();

        c = (a+b)/2;
        System.out.println("c = " +  c);
    }
}
