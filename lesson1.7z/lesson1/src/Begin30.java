import java.util.Scanner;

public class Begin30 {
    public static void main(String[] args) {
        // rad = (a*pi)/180  a = (rad*180)/pi

        double a, pi = Math.PI, rad;
        Scanner in = new Scanner(System.in);
        rad = in.nextDouble();

        a = (rad*180)/pi;

        System.out.println("a = " + a);

    }
}
