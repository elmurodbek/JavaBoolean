import java.util.Scanner;

public class Begin16 {
    public static void main(String[] args) {
        System.out.println("x1 = ");
        Scanner in = new Scanner(System.in);
        int x1,x2,n;
        x1 = in.nextInt();
        System.out.println("x2 = ");
        x2 = in.nextInt();
        n = Math.abs(x1-x2);
        System.out.println("n = " + n);
    }
}
