import java.util.Scanner;

public class Begin4 {
    public static void main(String[] args) {
        double L, d;
        double p = 3.14;

        Scanner son = new Scanner(System.in);
        System.out.println("L = d * PI\nd = ");
        d = son.nextDouble();

        L = d*p;

        System.out.println("L = " + L);
    }
}
