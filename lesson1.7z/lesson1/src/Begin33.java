import java.util.Scanner;

public class Begin33 {
    public static void main(String[] args) {
        System.out.println("x kg konfet a so`m, 1 va y kg qancha");
        Scanner in = new Scanner(System.in);
        int x,a,y,x1,y1;
        System.out.println("x = ");
        x = in.nextInt();
        System.out.println("a = ");
        a = in.nextInt();

        x1 = a/x;
        System.out.println("1kg = " + x1 + " sum");
        System.out.println("y = ");
        y = in.nextInt();
        y1 = y * x1;
        System.out.println(" "+y1 + " sum");
    }
}
