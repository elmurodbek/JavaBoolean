import java.util.Scanner;

public class Begin2 {
    public static void main(String[] args) {
        double S, a;

        Scanner input = new Scanner(System.in);
        System.out.println("S = a^2");
        System.out.print("a = ");
        a = input.nextDouble();

        S = a*a;

        System.out.println("S = " + S);
    }
}
