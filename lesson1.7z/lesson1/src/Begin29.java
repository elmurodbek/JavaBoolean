import java.util.Scanner;

public class Begin29 {
    public static void main(String[] args) {
        System.out.println("rad = (x*180)/pi");
        double a = Math.PI;
        double rad, x;
        // x = (rad*pi)/180
        Scanner in = new Scanner(System.in);
        x = in.nextInt();
        rad = (x*a)/180;
        System.out.println("rad = " + rad);
    }
}
