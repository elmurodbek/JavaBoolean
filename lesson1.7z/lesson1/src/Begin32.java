import java.util.Scanner;

public class Begin32 {
    public static void main(String[] args) {
        System.out.println("F=(C*9/5)+32");
        Scanner in = new Scanner(System.in);
        double C,F;
        C = in.nextDouble();
        F = (C*9/5)+32;
        System.out.println("F = " + F);
    }
}
