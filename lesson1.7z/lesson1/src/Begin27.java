import java.util.Scanner;

public class Begin27 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a;
        double a2,a4,a8;
        a = in.nextInt();
        a2 = a*a;
        a4 = a*a*a*a;
        a8 = Math.pow(a,8);
        System.out.println("a^2 = " + a2 + " a4 = " + a4 + " a8 = " + a8);
    }
}
