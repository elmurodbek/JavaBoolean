import java.util.Scanner;

public class Begin12 {
    public static void main(String[] args) {
        System.out.println("c = sqrt( a^2 + b^2 )  /  P = a + b + c");
        int a,b;
        double P,c;
        Scanner in = new Scanner(System.in);
        System.out.println("a = ");
        a = in.nextInt();
        System.out.println("b = ");
        b = in.nextInt();

        c = Math.sqrt((a*a) + (b*b));
        P = a + b + c;

        System.out.println("P = " + P);

    }
}
