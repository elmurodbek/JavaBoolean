import java.util.Scanner;

public class Begin9 {
    public static void main(String[] args) {
        double a,b,c;
        System.out.println("c = sqrt(a*b)");
        Scanner in = new Scanner(System.in);
        System.out.print("a = ");
        a = in.nextDouble();
        System.out.println("b = ");
        b = in.nextDouble();

        c = Math.sqrt( Math.abs(a) * Math.abs(b));

        System.out.println("c = " + c);

    }
}
