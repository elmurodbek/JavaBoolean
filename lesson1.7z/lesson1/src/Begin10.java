import java.util.Scanner;

public class Begin10 {
    public static void main(String[] args) {
        System.out.println("a+b  /  a*b  /  a^2 b^2");
        int a, b, c;
        Scanner in = new Scanner(System.in);
        a = in.nextInt();
        b = in.nextInt();
        c = a+b;
        System.out.println("yigindisi: " + c);
        System.out.println("ko`paytmasi: " + a*b);
        System.out.println("Kvadrati: " + a*a + " " + b*b);
    }
}
