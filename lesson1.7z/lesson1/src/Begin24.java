import java.util.Scanner;

public class Begin24 {
    public static void main(String[] args) {
        System.out.println("ac cb ba");
        int a,b,c,d;
        Scanner in = new Scanner(System.in);
        a = in.nextInt();
        b = in.nextInt();
        c = in.nextInt();
        d = a;
        a = c;
        c = b;
        b = d;
        System.out.println(a + " " + b + " " + c);
    }
}
