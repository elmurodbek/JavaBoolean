import java.util.Scanner;

public class Begin25 {
    public static void main(String[] args) {
        System.out.println("y = 3x^6 - 6x^2 - 7");
        Scanner in = new Scanner(System.in);
        int x;
        double y;
        x = in.nextInt();
        y = 3*Math.pow(x, 6) - 6*x*x -7;
        System.out.println("y = " + y);
    }
}
