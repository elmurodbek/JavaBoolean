import java.util.Scanner;

public class Begin1 {
    public static void main(String[] args) {

        double P, a;

        Scanner input = new Scanner(System.in);
        System.out.print("a = ");
        a = input.nextDouble();
        P=4*a;
        System.out.print("P = 4*a    ");
        System.out.println("P = " + P);
    }
}
