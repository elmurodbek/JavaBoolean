import java.util.Scanner;

public class Begin31 {
    public static void main(String[] args) {
        System.out.println("C = (F - 32) * 5/9");
        System.out.println("F = ");
        double F,C;
        Scanner in = new Scanner(System.in);
        F = in.nextDouble();
        C = (F-32)*(5/9);
        System.out.println("C = " + C);
    }
}
