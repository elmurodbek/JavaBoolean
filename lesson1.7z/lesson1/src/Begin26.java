import java.util.Scanner;

public class Begin26 {
    public static void main(String[] args) {
        System.out.println("x = ");
        int x;
        double y;
        Scanner in = new Scanner(System.in);
        x = in.nextInt();
        y = 4*Math.pow((x-3),6 ) - 7*Math.pow((x-3),3) + 2;
        System.out.println("y = " + y);
    }
}
