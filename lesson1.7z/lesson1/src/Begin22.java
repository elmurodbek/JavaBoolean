import java.util.Scanner;

public class Begin22 {
    public static void main(String[] args) {
        System.out.println("a va b qiymatlar almashsin");
        int a,b,c;
        Scanner in = new Scanner(System.in);
        System.out.println("a = ");
        a = in.nextInt();

        System.out.println("b = ");
        b = in.nextInt();

        c = a;
        a = b;
        b = c;
        System.out.println("a = " + a + " b = " + b);
    }
}
