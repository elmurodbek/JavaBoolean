import java.util.Scanner;

public class Begin13 {
    public static void main(String[] args) {
        int r1, r2;
        double s1,s2,s3;

        Scanner in = new Scanner(System.in);
        System.out.println("r1 = ");
        r1 = in.nextInt();
        r2 = in.nextInt();

        double x = Math.PI;

        s1 = x*r1;
        s2 = x*r2;
        s3 = x*(r1-r2);

        System.out.println("s1 = " + s1 + " s2 = " + s2 + " s3 = " + s3);
    }
}
